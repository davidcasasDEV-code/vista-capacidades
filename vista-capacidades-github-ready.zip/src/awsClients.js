const { config } = require("./config");

function loadAwsSdk() {
  try {
    const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
    const { DynamoDBDocumentClient, DeleteCommand, GetCommand, PutCommand, ScanCommand, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
    const { LambdaClient, InvokeCommand } = require("@aws-sdk/client-lambda");

    return {
      DynamoDBClient,
      DynamoDBDocumentClient,
      DeleteCommand,
      GetCommand,
      PutCommand,
      ScanCommand,
      UpdateCommand,
      LambdaClient,
      InvokeCommand
    };
  } catch (error) {
    const friendly = new Error(
      "Faltan dependencias AWS SDK. Ejecuta `npm install` y configura .env antes de usar DATA_MODE=aws."
    );
    friendly.cause = error;
    throw friendly;
  }
}

function createClients() {
  const sdk = loadAwsSdk();
  const dynamoClient = new sdk.DynamoDBClient({ region: config.awsRegion });
  const docClient = sdk.DynamoDBDocumentClient.from(dynamoClient, {
    marshallOptions: {
      removeUndefinedValues: true
    }
  });
  const lambdaClient = new sdk.LambdaClient({ region: config.awsRegion });

  return {
    ...sdk,
    docClient,
    lambdaClient
  };
}

module.exports = {
  createClients
};
